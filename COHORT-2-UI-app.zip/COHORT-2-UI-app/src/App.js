import React from 'react';
import './App.css';
import AppRouter from './Routers/AppRouter';


const App = () => <AppRouter /> ;

export default App;