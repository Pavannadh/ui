import React from 'react';
import './App.css';
import AppRouter from './routers/AppRouter';


const App = () => <AppRouter /> ;

export default App;
