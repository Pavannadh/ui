import React from 'react'
import './Main.css'

const  Footer=()=>{
    
    return(
            <div className='footer'>
                <p></p>
            </div>
        );
}

export default Footer



